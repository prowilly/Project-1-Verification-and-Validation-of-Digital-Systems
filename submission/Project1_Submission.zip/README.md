# Project 1 submission

Team: William Garland, Banmeet Singh, Daniel Jo. Course: EEE 4701.

[Project report](REPORT.pdf) · [Demo](https://www.youtube.com/watch?v=xh-gOgaW6KI)

Run `make SIM=icarus SEED=4701 N_CYCLES=5000` from this extracted directory.
Prerequisites: Python 3.12, Icarus Verilog 12.0, and `python -m pip install -r requirements.txt` in your Python environment.

There is exactly one test module, `test_fifo.py`, containing `test_crv_seeded_regression`.
It is copied unchanged from Banmeet's `crv/test_fifo.py`. The driver/monitor/scoreboard helpers are in `tb/`, the reference queue is in `lib/`, and the unchanged coverage model is in `coverage/`.
The only Makefile is here at the root. `make DUT=/absolute/path/to/fifo.sv` supports a replacement RTL file; use a fresh build between variants. Do not count make's exit status alone as a test result: inspect `results.xml` and the simulation summary.

Required documents: [vplan.md](vplan.md), [closure.md](closure.md), [FINDINGS.md](FINDINGS.md), [CONTRIBUTIONS.md](CONTRIBUTIONS.md), [ai_log.md](ai_log.md), and [REPORT.pdf](REPORT.pdf).
The released pool is [mutants_released.yaml](mutants_released.yaml). Source-copy hashes and package adaptations are recorded in [source_manifest.json](source_manifest.json).

The repository's separate directed test module and runner unit tests are excluded from this upload to avoid ambiguous test-directory selection. Their prior evidence is retained and clearly distinguished from the submitted CRV test. Default coverage is complete; supplemental coverage and distribution limitations remain documented honestly.
